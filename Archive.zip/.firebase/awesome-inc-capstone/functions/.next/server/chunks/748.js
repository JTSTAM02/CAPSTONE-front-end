"use strict";
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 4599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/MovieMixerLogo.3b9e1584.png","height":427,"width":650,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAG1BMVEUyUU1CXlspSUQdQD1LZmRAWFFMYFNTZ1VabVvC350GAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAKElEQVR4nCXGyQ0AMAgDsBwE2H9iVNUvw0LIKliY/VF3SFiZ7RC28BwLTgB5vTJxIQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _images_MovieMixerLogo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4599);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




function Header() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container-fluid d-flex flex-column align-items-center text-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            className: "rounded-img",
            src: _images_MovieMixerLogo_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            alt: "MovieMixer Logo",
            width: 180,
            height: 180
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ }),

/***/ 5246:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LW: () => (/* binding */ LOGIN_ENDPOINT),
/* harmony export */   Q: () => (/* binding */ REFRESH_ENDPOINT),
/* harmony export */   T5: () => (/* binding */ API_URL),
/* harmony export */   bc: () => (/* binding */ REGISTER_ENDPOINT)
/* harmony export */ });
const API_URL = "https://awesome-inc-capstone.uk.r.appspot.com/api";
const LOGIN_ENDPOINT = "user/login/";
const REGISTER_ENDPOINT = "user/signup/";
const REFRESH_ENDPOINT = "token/refresh/";


/***/ })

};
;